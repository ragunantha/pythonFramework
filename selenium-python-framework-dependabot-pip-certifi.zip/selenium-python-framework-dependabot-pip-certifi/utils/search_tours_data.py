class SearchToursData:

    def __init__(self, destination, tour_type, start_year, start_month, start_day, adults_num):
        self.destination = destination
        self.tour_type = tour_type
        self.start_year = start_year
        self.start_month = start_month
        self.start_day = start_day
        self.adults_num = adults_num
