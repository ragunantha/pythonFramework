class SearchHotelsData:

    def __init__(self, destination, check_in, check_out, adults_num, kids_num):
        self.destination = destination
        self.check_in = check_in
        self.check_out = check_out
        self.adults_num = adults_num
        self.kids_num = kids_num
