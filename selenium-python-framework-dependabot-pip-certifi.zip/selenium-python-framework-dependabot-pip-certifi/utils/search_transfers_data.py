class SearchTransfersData:

    def __init__(self, pick_up_loc, drop_off_loc, depart_year, depart_month, depart_day, depart_time,
                 return_year, return_month, return_day, return_time):
        self.pick_up_loc = pick_up_loc
        self.drop_off_loc = drop_off_loc
        self.depart_year = depart_year
        self.depart_month = depart_month
        self.depart_day = depart_day
        self.depart_time = depart_time
        self.return_year = return_year
        self.return_month = return_month
        self.return_day = return_day
        self.return_time = return_time
